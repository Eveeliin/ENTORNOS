/**
 * <h1>Pacientes</h1>
 *
 * @see <a href="https://drive.google.com/file/d/1DjAgSGAfeLIepwsPRN_ihTKeCdJwCYdh/view">Referencia</a>
 * @version 3-2021
 * @author Evelin Reyes
 * @since v1
 */

public class Paciente {

    //Atributos
    /**
     * Atributo nombre del Paciente
     */
    String nombre;
    /**
     * Atributo edad del Paciente
     */
    int edad;
    /**
     * Atributo donde se guardan la opciones de distintos síntomas en una lista
     */
    String[] síntomas;

    /**
     * Objeto paciente creado con los atributos antes declarados
     */

    public Paciente(){
        this.nombre = "Desconocido";
        this.edad = 999;
        this.síntomas = new String[]{"Ninguno"};
    }

    //Constructor
    /**
     * Esto es un constructor con 3 parámetros
     * Crea objetos de tipo paciente, donde irán:
     * @param nombre nombre del paciente
     * @param edad edad del paciente
     * @param síntomas síntomas del paciente
     */

    public Paciente(String nombre, int edad, String[] síntomas) {
        this.nombre = nombre;
        this.edad = edad;
        this.síntomas = síntomas;
    }

    /**
     * Devuelve y permite los cambios en el atributo nombre
     * @return nombre
     */

    public String getNombre() {
        return nombre;
    }

    /**
     * Guarda los cambios y no permite nulo en:
     * @param nombre
     *
     */

    public void setNombre(String nombre) {
        if (!nombre.equals(null)){
            this.nombre = nombre;
        }
    }

    /**
     * Devuelve los cambios realizados en el atributo edad
     * @return edad
     */

    public int getEdad() {
        return edad;
    }

    /**
     * Guarda los cambios en:
     * @param edad
     */

    public void setEdad(int edad) {
        this.edad = edad;
    }

    /**
     * Devuelve los cambios realizados en el atributo síntomas
     * @return síntomas
     */

    public String[] getSíntomas() {
        return síntomas;
    }

    /**
     * Guarda los cambios que se realicen en:
     * @param síntomas
     */

    public void setSíntomas(String[] síntomas) {
        this.síntomas = síntomas;
    }
}
